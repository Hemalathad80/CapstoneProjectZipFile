# EzyerTrade
Stock Management Command Line App
