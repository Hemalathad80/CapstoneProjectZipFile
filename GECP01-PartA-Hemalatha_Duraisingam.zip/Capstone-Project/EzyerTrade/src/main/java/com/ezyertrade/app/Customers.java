package com.ezyertrade.app;

public class Customers {
    //Customer variables
    String emailId;
    String password;

    //Constructor
    public Customers() {
        this.emailId = emailId;
        this.password = password;
    }

    //Getters and Setters
    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
